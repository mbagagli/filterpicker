__name__ = "filterpicker"
__author__ = "Matteo Bagagli"
__version__ = "1.0.1"
__date__ = "06/2019"
